package pl.rynekbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class BotConfig {
    public static class Entry {
        /** id przedmiotu (np. "diamond", "minecraft:diamond") albo fragment nazwy (itemy customowe). */
        public String item = "";
        /** opcjonalna ręczna cena odniesienia za 1 szt. Puste = używa najniższej ceny ze skanu. */
        public String sellPrice = "";
        /** opcjonalny własny zysk za 1 szt.: kwota (500, 1.5k) albo procent (10%). Puste = suwak globalny. */
        public String profit = "";
        /** najniższa cena za 1 szt. znaleziona ostatnim skanem (0 = brak). */
        public double scanned = 0;

        public double sell() {
            return Price.parseField(sellPrice);
        }

        /** Cena odniesienia: ręczna, a jeśli jej nie ma - najniższa ze skanu. */
        public double ref() {
            double s = sell();
            return s > 0 ? s : scanned;
        }

        /** Maksymalna cena zakupu za 1 szt. lub -1 gdy brak ceny odniesienia / niepoprawny zysk. */
        public double maxBuy(int globalPercent) {
            double ref = ref();
            if (ref <= 0) return -1;
            String p = profit == null ? "" : profit.trim();
            double prof;
            if (p.isEmpty()) {
                prof = ref * globalPercent / 100.0;
            } else if (p.endsWith("%")) {
                double pc = Price.parseField(p.substring(0, p.length() - 1));
                if (pc < 0) return -1;
                prof = ref * pc / 100.0;
            } else {
                prof = Price.parseField(p);
                if (prof < 0) return -1;
            }
            return ref - prof;
        }
    }

    public List<Entry> entries = new ArrayList<>();
    /** Globalny profit 1-100%: kupuj, gdy cena <= cena odniesienia * (1 - profit%). */
    public int profitPercent = 20;
    /** Po zakończonym skanie od razu włącz kupowanie. */
    public boolean autoBuyAfterScan = true;
    public String marketCommand = "ah";
    public int refreshMs = 400;
    /** Regex na cenę w lore oferty: grupa 1 = liczba, grupa 2 = opcjonalny sufiks k/m/b/mld. */
    public String priceRegex = "(?i)(?:koszt|cena|price)\\D{0,8}([0-9][0-9\\s.,]*)\\s*(mld|[kmb])?";

    // Sloty okna rynku (domyślnie z gotowego profilu anarchia w BK-Rynek - do sprawdzenia /rynekbot dump).
    public int nextPageSlot = 26;
    public int confirmSlot = 11;
    public boolean sortEnabled = true;
    public int sortingSlot = 53;
    public String sortingKeyword = "najnowsz";
    public int maxScanPages = 300;

    /** Itemy rozpoznawane jako przycisk "kup", gdy confirmSlot < 0. */
    public List<String> confirmItems = new ArrayList<>(List.of(
            "minecraft:lime_stained_glass_pane",
            "minecraft:green_stained_glass_pane",
            "minecraft:emerald_block"));

    private static BotConfig instance;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("rynekbot.json");
    }

    public static BotConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                instance = GSON.fromJson(Files.readString(p), BotConfig.class);
            }
        } catch (Exception e) {
            RynekBotClient.LOGGER.warn("Nie udało się wczytać configu", e);
        }
        if (instance == null) instance = new BotConfig();
        if (instance.entries == null) instance.entries = new ArrayList<>();
        instance.profitPercent = Math.max(1, Math.min(100, instance.profitPercent));
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(get()));
        } catch (IOException e) {
            RynekBotClient.LOGGER.warn("Nie udało się zapisać configu", e);
        }
    }
}
