package pl.rynekbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RynekBotClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("rynekbot");

    private static KeyBinding openKey;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        BotConfig.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.rynekbot.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, "category.rynekbot"));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.rynekbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, "category.rynekbot"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new BotScreen());
            }
            while (toggleKey.wasPressed()) {
                MarketBot.INSTANCE.toggle();
            }
            MarketBot.INSTANCE.tick(client);
        });

        // Bot cały czas trzyma otwarte okno /ah, więc O i P muszą działać także w nim.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GenericContainerScreen) {
                ScreenKeyboardEvents.allowKeyPress(screen).register((s, key, scancode, modifiers) -> {
                    if (toggleKey.matchesKey(key, scancode)) {
                        MarketBot.INSTANCE.toggle();
                        return false;
                    }
                    if (openKey.matchesKey(key, scancode)) {
                        MinecraftClient mc = MinecraftClient.getInstance();
                        if (mc.player != null) mc.player.closeHandledScreen();
                        mc.setScreen(new BotScreen());
                        return false;
                    }
                    return true;
                });
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("rynekbot")
                        .then(ClientCommandManager.literal("start").executes(ctx -> {
                            MarketBot.INSTANCE.setRunning(true);
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("stop").executes(ctx -> {
                            MarketBot.INSTANCE.setRunning(false);
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("scan").executes(ctx -> {
                            MarketBot.INSTANCE.startScan(MinecraftClient.getInstance());
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("dump").executes(ctx -> {
                            ctx.getSource().sendFeedback(Text.literal("[RynekBot] Otwieram rynek i zrzucam oferty..."));
                            MarketBot.INSTANCE.requestDump(MinecraftClient.getInstance());
                            return 1;
                        }))));
    }
}
