package pl.rynekbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class BotScreen extends Screen {
    private static final int ROWS = 5;
    private static final int W_ITEM = 120;
    private static final int W_NUM = 64;
    private static final int W_INFO = 90;
    private static final int GAP = 4;

    private int scroll;
    private int left;
    private int top;
    private int totalW;
    private int statusY;
    private final List<BotConfig.Entry> shown = new ArrayList<>();

    public BotScreen() {
        super(Text.literal("RynekBot"));
    }

    /** Suwak profitu 1-100%. */
    private static class ProfitSlider extends SliderWidget {
        ProfitSlider(int x, int y, int w, int h, int percent) {
            super(x, y, w, h, Text.empty(), (percent - 1) / 99.0);
            updateMessage();
        }

        private int percent() {
            return 1 + (int) Math.round(value * 99);
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Profit: " + percent() + "%  (kup <= najniższa - " + percent() + "%)"));
        }

        @Override
        protected void applyValue() {
            BotConfig.get().profitPercent = percent();
        }
    }

    private Text toggleText() {
        return Text.literal(MarketBot.INSTANCE.running ? "STOP" : "START")
                .formatted(MarketBot.INSTANCE.running ? Formatting.RED : Formatting.GREEN);
    }

    private TextFieldWidget field(int x, int y, int w, String value, String hint, Consumer<String> onChange) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y, w, 20, Text.literal(hint));
        f.setMaxLength(120);
        f.setPlaceholder(Text.literal(hint).formatted(Formatting.DARK_GRAY));
        f.setText(value == null ? "" : value);
        f.setChangedListener(onChange);
        addDrawableChild(f);
        return f;
    }

    @Override
    protected void init() {
        BotConfig cfg = BotConfig.get();
        List<BotConfig.Entry> es = cfg.entries;
        totalW = W_ITEM + GAP + W_NUM + GAP + W_NUM + GAP + 20 + GAP + W_INFO;
        left = (width - totalW) / 2;
        top = 36;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, es.size() - ROWS)));
        shown.clear();

        for (int r = 0; r < ROWS; r++) {
            int idx = scroll + r;
            if (idx >= es.size()) break;
            BotConfig.Entry e = es.get(idx);
            shown.add(e);
            int y = top + 14 + r * 24;
            int x = left;
            field(x, y, W_ITEM, e.item, "np. diamond", s -> e.item = s);
            x += W_ITEM + GAP;
            field(x, y, W_NUM, e.sellPrice, "ref./auto", s -> e.sellPrice = s);
            x += W_NUM + GAP;
            field(x, y, W_NUM, e.profit, "zysk/suwak", s -> e.profit = s);
            x += W_NUM + GAP;
            addDrawableChild(ButtonWidget.builder(Text.literal("X"), b -> {
                es.remove(e);
                BotConfig.save();
                clearAndInit();
            }).dimensions(x, y, 20, 20).build());
        }

        int by = top + 14 + ROWS * 24 + 6;
        addDrawableChild(ButtonWidget.builder(Text.literal("+ Dodaj"), b -> {
            es.add(new BotConfig.Entry());
            scroll = Math.max(0, es.size() - ROWS);
            clearAndInit();
        }).dimensions(left, by, 70, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Skanuj rynek"), b -> {
            BotConfig.save();
            MinecraftClient mc = MinecraftClient.getInstance();
            close();
            MarketBot.INSTANCE.startScan(mc);
        }).dimensions(left + 74, by, 100, 20).build());

        ButtonWidget toggleBtn = ButtonWidget.builder(toggleText(), b -> {
            MarketBot.INSTANCE.setRunning(!MarketBot.INSTANCE.running);
            b.setMessage(toggleText());
        }).dimensions(left + 178, by, 80, 20).build();
        addDrawableChild(toggleBtn);

        addDrawableChild(ButtonWidget.builder(Text.literal("Gotowe"), b -> close())
                .dimensions(left + totalW - 70, by, 70, 20).build());

        int by2 = by + 24;
        addDrawableChild(new ProfitSlider(left, by2, 220, 20, cfg.profitPercent));
        addDrawableChild(ButtonWidget.builder(autoText(cfg), b -> {
            cfg.autoBuyAfterScan = !cfg.autoBuyAfterScan;
            b.setMessage(autoText(cfg));
        }).dimensions(left + 224, by2, 150, 20).build());

        int by3 = by2 + 24;
        field(left, by3, 70, cfg.marketCommand, "komenda", s -> cfg.marketCommand = s.trim());
        field(left + 74, by3, 70, String.valueOf(cfg.refreshMs), "odśw. ms", s -> {
            try {
                cfg.refreshMs = Math.max(50, Math.min(10000, Integer.parseInt(s.trim())));
            } catch (NumberFormatException ignored) {
                // zostaje poprzednia wartość
            }
        });
        statusY = by3 + 26;
    }

    private Text autoText(BotConfig cfg) {
        return Text.literal("Po skanie: " + (cfg.autoBuyAfterScan ? "KUPUJ" : "tylko skan"));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int max = Math.max(0, BotConfig.get().entries.size() - ROWS);
        int next = Math.max(0, Math.min(max, scroll - (int) Math.signum(verticalAmount)));
        if (next != scroll) {
            scroll = next;
            clearAndInit();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFF);
        int gray = 0xA0A0A0;
        ctx.drawTextWithShadow(textRenderer, "Przedmiot", left, top + 2, gray);
        ctx.drawTextWithShadow(textRenderer, "Cena ref.", left + W_ITEM + GAP, top + 2, gray);
        ctx.drawTextWithShadow(textRenderer, "Zysk", left + W_ITEM + W_NUM + GAP * 2, top + 2, gray);
        ctx.drawTextWithShadow(textRenderer, "Najniższa (skan)",
                left + W_ITEM + W_NUM * 2 + GAP * 4 + 20, top + 2, gray);

        BotConfig cfg = BotConfig.get();
        for (int r = 0; r < shown.size(); r++) {
            BotConfig.Entry e = shown.get(r);
            int y = top + 14 + r * 24 + 6;
            String info = Price.format(e.scanned);
            double mb = e.maxBuy(cfg.profitPercent);
            if (mb > 0) info += " > " + Price.format(mb);
            ctx.drawTextWithShadow(textRenderer, info, left + W_ITEM + W_NUM * 2 + GAP * 4 + 20, y,
                    mb > 0 ? 0x55FF55 : 0x808080);
        }

        MarketBot bot = MarketBot.INSTANCE;
        String status = bot.scanning ? "SKANOWANIE... strona " + bot.scanPages
                : (bot.running ? "KUPUJE" : "ZATRZYMANY");
        ctx.drawTextWithShadow(textRenderer, status + "  |  kliknięte oferty: " + bot.clicks,
                left, statusY, (bot.running || bot.scanning) ? 0x55FF55 : 0xFF5555);
        ctx.drawTextWithShadow(textRenderer,
                "Zielone: najniższa cena > do ilu kupuje. Cena ref. puste = najniższa ze skanu; Zysk puste = suwak.",
                left, statusY + 12, 0x808080);
        ctx.drawTextWithShadow(textRenderer,
                "P (także w oknie rynku) = start/stop kupowania lub anulowanie skanu. O = to okno.",
                left, statusY + 24, 0x808080);
    }

    @Override
    public void removed() {
        BotConfig.save();
    }
}
