package pl.rynekbot.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.InventoryS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.rynekbot.MarketBot;

/** Reakcja na dane z serwera od razu po odebraniu pakietu, bez czekania na następny tick. */
@Mixin(ClientPlayNetworkHandler.class)
public class NetHandlerMixin {
    @Inject(method = "onInventory", at = @At("TAIL"))
    private void rynekbot$onInventory(InventoryS2CPacket packet, CallbackInfo ci) {
        MarketBot.INSTANCE.onPacket(MinecraftClient.getInstance());
    }

    @Inject(method = "onScreenHandlerSlotUpdate", at = @At("TAIL"))
    private void rynekbot$onSlotUpdate(ScreenHandlerSlotUpdateS2CPacket packet, CallbackInfo ci) {
        MarketBot.INSTANCE.onPacket(MinecraftClient.getInstance());
    }
}
