package pl.rynekbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.IdentityHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Logika autorynku.
 * - SKAN: przechodzi po wszystkich stronach rynku i zapisuje najniższą cenę za 1 szt. każdego przedmiotu z listy.
 * - KUPOWANIE: kupuje oferty tańsze niż cena odniesienia * (1 - profit%). Reaguje od razu po pakiecie z serwera (mixin).
 */
public final class MarketBot {
    public static final MarketBot INSTANCE = new MarketBot();

    public volatile boolean running;
    public volatile boolean scanning;
    public volatile boolean dumpNext;
    public int clicks;
    public int scanPages;

    // kupowanie
    private long lastOpen;
    private int marketSyncId = -1;
    private boolean awaitingConfirm;
    private long clickedAt;
    private int lastSlot = -1;
    private double lastPrice = -1;
    private int sortSyncId = -1;
    private int sortAttempts;
    private long lastSortClick;
    private Pattern pricePattern;
    private String patternSrc;

    // skan
    private final Map<BotConfig.Entry, Double> scanMin = new IdentityHashMap<>();
    private int lastHash;
    private int stableTicks;
    private int processedHash;
    private boolean processedAny;
    private long nextClickedAt;
    private long scanLastProgress;

    private MarketBot() {}

    private static void msg(String s, boolean overlay) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) c.player.sendMessage(Text.literal("[RynekBot] " + s), overlay);
    }

    /** P: anuluje skan, a poza skanem przełącza kupowanie. */
    public void toggle() {
        if (scanning) {
            scanning = false;
            msg("Skan anulowany", true);
        } else {
            setRunning(!running);
        }
    }

    public void setRunning(boolean on) {
        if (on) scanning = false;
        running = on;
        awaitingConfirm = false;
        lastOpen = 0;
        msg(on ? "KUPOWANIE: START" : "KUPOWANIE: STOP", true);
    }

    public void requestDump(MinecraftClient client) {
        dumpNext = true;
        openMarket(client);
    }

    // ---------------------------------------------------------------- SKAN

    public void startScan(MinecraftClient client) {
        BotConfig cfg = BotConfig.get();
        boolean any = false;
        for (BotConfig.Entry e : cfg.entries) {
            if (e.item != null && !e.item.isBlank()) any = true;
        }
        if (!any) {
            msg("Dodaj przynajmniej jeden przedmiot do listy (O).", false);
            return;
        }
        if (client.player == null) return;
        running = false;
        awaitingConfirm = false;
        scanning = true;
        scanPages = 0;
        scanMin.clear();
        lastHash = 0;
        stableTicks = 0;
        processedAny = false;
        scanLastProgress = System.currentTimeMillis();
        msg("SKAN rynku start...", true);
        openMarket(client);
    }

    private void scanTick(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        BotConfig cfg = BotConfig.get();
        long now = System.currentTimeMillis();
        ScreenHandler h = p.currentScreenHandler;
        if (!(h instanceof GenericContainerScreenHandler g)) {
            if (scanPages == 0 && now - lastOpen >= 1500) openMarket(client);
            if (now - scanLastProgress > 8000) finishScan(client, false);
            return;
        }
        int size = g.getRows() * 9;
        int hash = contentHash(h, size);
        if (hash == lastHash) {
            stableTicks++;
        } else {
            lastHash = hash;
            stableTicks = 0;
        }

        if (stableTicks >= 2 && !(processedAny && hash == processedHash)) {
            processPage(h, size, cfg);
            processedAny = true;
            processedHash = hash;
            scanPages++;
            scanLastProgress = now;
            if (scanPages >= cfg.maxScanPages) {
                finishScan(client, true);
                return;
            }
            int ns = cfg.nextPageSlot;
            if (ns < 0 || ns >= size || h.getSlot(ns).getStack().isEmpty()) {
                finishScan(client, true);
                return;
            }
            client.interactionManager.clickSlot(h.syncId, ns, 0, SlotActionType.PICKUP, p);
            nextClickedAt = now;
            p.sendMessage(Text.literal("[RynekBot] Skan: strona " + scanPages), true);
        } else if (processedAny && hash == processedHash && now - nextClickedAt > 2000) {
            // po kliknięciu "dalej" nic się nie zmieniło = ostatnia strona
            finishScan(client, true);
        } else if (now - scanLastProgress > 8000) {
            finishScan(client, false);
        }
    }

    private void processPage(ScreenHandler h, int size, BotConfig cfg) {
        for (int i = 0; i < size; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (st.isEmpty()) continue;
            double total = readPrice(st, cfg);
            if (total <= 0) continue;
            double unit = total / st.getCount();
            for (BotConfig.Entry e : cfg.entries) {
                if (matches(e, st)) scanMin.merge(e, unit, Math::min);
            }
        }
    }

    private void finishScan(MinecraftClient client, boolean completed) {
        scanning = false;
        BotConfig cfg = BotConfig.get();
        ClientPlayerEntity p = client.player;
        int found = 0;
        for (BotConfig.Entry e : cfg.entries) {
            Double v = scanMin.get(e);
            if (v != null) {
                e.scanned = v;
                found++;
            } else if (completed) {
                e.scanned = 0;
            }
        }
        BotConfig.save();
        if (p != null) {
            p.sendMessage(Text.literal("[RynekBot] Skan " + (completed ? "zakończony" : "przerwany")
                    + ": stron " + scanPages + ", znaleziono ceny dla " + found + " z " + cfg.entries.size()
                    + " przedmiotów."), false);
            int shown = 0;
            for (BotConfig.Entry e : cfg.entries) {
                if (shown++ >= 10) break;
                double mb = e.maxBuy(cfg.profitPercent);
                p.sendMessage(Text.literal("  " + e.item + ": najniższa " + Price.format(e.scanned)
                        + (mb > 0 ? " -> kupuję do " + Price.format(mb) : " (brak ceny)")), false);
            }
        }
        if (completed && found > 0 && cfg.autoBuyAfterScan) {
            setRunning(true);
        } else if (p != null && !running) {
            p.closeHandledScreen();
        }
    }

    private int contentHash(ScreenHandler h, int size) {
        int x = 17;
        for (int i = 0; i < size; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (st.isEmpty()) {
                x = x * 31;
                continue;
            }
            x = x * 31 + Registries.ITEM.getId(st.getItem()).hashCode();
            x = x * 31 + st.getCount();
            LoreComponent lore = st.get(DataComponentTypes.LORE);
            if (lore != null) {
                for (Text t : lore.lines()) x = x * 31 + t.getString().hashCode();
            }
        }
        return x;
    }

    // ------------------------------------------------------------ KUPOWANIE

    /** Wołane co tick klienta. */
    public void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (!(running || scanning || dumpNext)) return;
        // nie przeszkadzamy w GUI moda, czacie, menu pauzy itp.
        if (client.currentScreen != null && !(client.currentScreen instanceof GenericContainerScreen)) {
            return;
        }
        if (scanning) {
            scanTick(client);
            return;
        }
        scan(client);
        long now = System.currentTimeMillis();
        boolean waitingConfirm = awaitingConfirm && now - clickedAt < 1500;
        if (!waitingConfirm && now - lastOpen >= BotConfig.get().refreshMs) {
            openMarket(client);
        }
    }

    /** Wołane z mixina zaraz po pakiecie z zawartością okna (wątek klienta). */
    public void onPacket(MinecraftClient client) {
        if (client.player == null || scanning || (!running && !dumpNext)) return;
        scan(client);
    }

    private void openMarket(MinecraftClient client) {
        lastOpen = System.currentTimeMillis();
        String cmd = BotConfig.get().marketCommand;
        if (cmd == null || cmd.isBlank()) cmd = "ah";
        if (cmd.startsWith("/")) cmd = cmd.substring(1);
        client.player.networkHandler.sendChatCommand(cmd);
    }

    private void scan(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (p == null || client.interactionManager == null || scanning) return;
        ScreenHandler h = p.currentScreenHandler;
        if (!(h instanceof GenericContainerScreenHandler g)) return;
        int size = g.getRows() * 9;
        long now = System.currentTimeMillis();
        BotConfig cfg = BotConfig.get();

        if (dumpNext) {
            dump(p, h, size);
            dumpNext = false;
            return;
        }
        if (!running) return;

        if (awaitingConfirm) {
            if (now - clickedAt > 1500) {
                awaitingConfirm = false;
            } else if (h.syncId != marketSyncId) {
                // otworzyło się okno potwierdzenia
                int slot = cfg.confirmSlot >= 0 && cfg.confirmSlot < size ? cfg.confirmSlot : findConfirm(h, size, cfg);
                if (slot >= 0 && !h.getSlot(slot).getStack().isEmpty()) {
                    awaitingConfirm = false;
                    client.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.PICKUP, p);
                }
                return;
            } else {
                // to samo okno = zakup bez potwierdzenia / odświeżenie
                awaitingConfirm = false;
            }
        }

        // sortowanie "najnowsze" (jeśli przycisk sortowania nie pokazuje jeszcze właściwego trybu)
        if (cfg.sortEnabled && cfg.sortingSlot >= 0 && cfg.sortingSlot < size
                && cfg.sortingKeyword != null && !cfg.sortingKeyword.isBlank()) {
            if (h.syncId != sortSyncId) {
                sortSyncId = h.syncId;
                sortAttempts = 0;
            }
            ItemStack s = h.getSlot(cfg.sortingSlot).getStack();
            if (!s.isEmpty() && sortAttempts < 6 && now - lastSortClick > 250
                    && !itemText(s).contains(cfg.sortingKeyword.toLowerCase(Locale.ROOT))) {
                sortAttempts++;
                lastSortClick = now;
                client.interactionManager.clickSlot(h.syncId, cfg.sortingSlot, 0, SlotActionType.PICKUP, p);
                return;
            }
        }

        int bestSlot = -1;
        double bestProfit = Double.NEGATIVE_INFINITY;
        double bestTotal = 0;
        for (int i = 0; i < size; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (st.isEmpty()) continue;
            double total = readPrice(st, cfg);
            if (total <= 0) continue;
            if (i == lastSlot && Math.abs(total - lastPrice) < 1e-9 && now - clickedAt < 700) continue;
            double unit = total / st.getCount();
            for (BotConfig.Entry e : cfg.entries) {
                double maxBuy = e.maxBuy(cfg.profitPercent);
                if (maxBuy <= 0 || !matches(e, st)) continue;
                if (unit <= maxBuy) {
                    double profit = (e.ref() - unit) * st.getCount();
                    if (profit > bestProfit) {
                        bestProfit = profit;
                        bestSlot = i;
                        bestTotal = total;
                    }
                }
            }
        }
        if (bestSlot >= 0) {
            marketSyncId = h.syncId;
            clickedAt = now;
            lastSlot = bestSlot;
            lastPrice = bestTotal;
            awaitingConfirm = true;
            clicks++;
            client.interactionManager.clickSlot(h.syncId, bestSlot, 0, SlotActionType.PICKUP, p);
            p.sendMessage(Text.literal("[RynekBot] Klik w ofertę (slot " + bestSlot + ", cena "
                    + (long) bestTotal + ", zysk ~" + (long) bestProfit + ")"), true);
        }
    }

    private int findConfirm(ScreenHandler h, int size, BotConfig cfg) {
        for (int i = 0; i < size; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (st.isEmpty()) continue;
            String id = Registries.ITEM.getId(st.getItem()).toString();
            if (cfg.confirmItems.contains(id)) return i;
        }
        return -1;
    }

    private String itemText(ItemStack st) {
        StringBuilder sb = new StringBuilder(st.getName().getString());
        LoreComponent lore = st.get(DataComponentTypes.LORE);
        if (lore != null) {
            for (Text t : lore.lines()) sb.append(' ').append(t.getString());
        }
        return sb.toString().replaceAll("§.", "").toLowerCase(Locale.ROOT);
    }

    private boolean matches(BotConfig.Entry e, ItemStack st) {
        String q = e.item == null ? "" : e.item.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return false;
        String id = Registries.ITEM.getId(st.getItem()).toString();
        Identifier idq = Identifier.tryParse(q.contains(":") ? q : "minecraft:" + q);
        if (idq != null && Registries.ITEM.containsId(idq)) {
            return id.equals(idq.toString());
        }
        return st.getName().getString().replaceAll("§.", "").toLowerCase(Locale.ROOT).contains(q);
    }

    private double readPrice(ItemStack st, BotConfig cfg) {
        LoreComponent lore = st.get(DataComponentTypes.LORE);
        if (lore == null) return -1;
        if (pricePattern == null || !cfg.priceRegex.equals(patternSrc)) {
            try {
                pricePattern = Pattern.compile(cfg.priceRegex);
                patternSrc = cfg.priceRegex;
            } catch (Exception ex) {
                return -1;
            }
        }
        for (Text line : lore.lines()) {
            String s = line.getString().replaceAll("§.", "");
            Matcher m = pricePattern.matcher(s);
            if (m.find()) {
                String suffix = m.groupCount() >= 2 ? m.group(2) : null;
                double v = Price.parse(m.group(1), suffix);
                if (v > 0) return v;
            }
        }
        return -1;
    }

    /** Kalibracja: wypisuje zawartość okna (id, nazwa, lore, wykryta cena) do czatu i logu. */
    private void dump(ClientPlayerEntity p, ScreenHandler h, int size) {
        BotConfig cfg = BotConfig.get();
        int shown = 0;
        for (int i = 0; i < size; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (st.isEmpty()) continue;
            StringBuilder sb = new StringBuilder();
            sb.append("[").append(i).append("] ")
                    .append(Registries.ITEM.getId(st.getItem())).append(" x").append(st.getCount())
                    .append(" | ").append(st.getName().getString());
            LoreComponent lore = st.get(DataComponentTypes.LORE);
            if (lore != null) {
                sb.append(" | ");
                for (Text t : lore.lines()) sb.append(t.getString().replaceAll("§.", "")).append(" / ");
            }
            sb.append(" => cena: ").append(readPrice(st, cfg));
            RynekBotClient.LOGGER.info(sb.toString());
            if (shown++ < 8) p.sendMessage(Text.literal(sb.toString()), false);
        }
        p.sendMessage(Text.literal("[RynekBot] Dump gotowy (pełny w logu). Jeśli 'cena: -1.0' przy ofertach, popraw priceRegex w config/rynekbot.json."), false);
    }
}
