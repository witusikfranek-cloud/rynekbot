package pl.rynekbot;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parsowanie cen: 1500, 1 500, 1,500, 1.5k, 2m, 1b, 2mld. */
public final class Price {
    private static final Pattern FIELD = Pattern.compile("^([0-9][0-9\\s.,]*)\\s*(mld|[kKmMbB])?$", Pattern.CASE_INSENSITIVE);

    private Price() {}

    public static double parse(String num, String suffix) {
        if (num == null) return -1;
        String s = num.replaceAll("\\s", "").replaceAll("[.,]+$", "");
        if (s.isEmpty()) return -1;
        double mult = 1;
        if (suffix != null && !suffix.isEmpty()) {
            String suf = suffix.toLowerCase();
            if (suf.equals("mld")) {
                mult = 1e9;
            } else {
                switch (suf.charAt(0)) {
                    case 'k' -> mult = 1e3;
                    case 'm' -> mult = 1e6;
                    case 'b' -> mult = 1e9;
                    default -> { }
                }
            }
            s = s.replace(',', '.');
        } else if (s.matches("\\d{1,3}([.,]\\d{3})+")) {
            s = s.replaceAll("[.,]", "");
        } else {
            s = s.replace(',', '.');
        }
        try {
            return Double.parseDouble(s) * mult;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Parsuje pole z GUI (np. "1.5k"). Zwraca -1 gdy niepoprawne lub puste. */
    public static double parseField(String text) {
        Matcher m = FIELD.matcher(text == null ? "" : text.trim());
        if (!m.matches()) return -1;
        return parse(m.group(1), m.group(2));
    }

    /** Ładny zapis do GUI: 12 345. */
    public static String format(double v) {
        if (v <= 0) return "-";
        return String.format(java.util.Locale.ROOT, "%,.0f", v).replace(',', ' ');
    }
}
