# RynekBot (Fabric 1.21.4)

Mod kliencki do automatycznego skanowania rynku (`/ah`) i kupowania ofert poniżej najniższej ceny.

## Jak działa
1. **O** – otwiera GUI. Dodajesz przedmioty (id np. `diamond` albo fragment nazwy dla itemów customowych).
2. **Skanuj rynek** – bot przechodzi po wszystkich stronach rynku i zapisuje **najniższą cenę za 1 szt.** każdego przedmiotu z listy (widać ją w kolumnie „Najniższa (skan)”).
3. **Suwak Profit 1–100 %** – ustala, o ile poniżej najniższej ceny ma kupować: `kup, gdy cena <= najniższa × (1 − profit%)`. Przykład: najniższa 10 000, profit 20 % → kupuje oferty do 8 000. Obok widać wyliczony próg („najniższa > do ilu kupuje”).
4. Po skanie bot **od razu zaczyna kupować** (przełącznik „Po skanie: KUPUJ / tylko skan”).

Opcjonalnie przy przedmiocie: **Cena ref.** (własna cena odniesienia zamiast skanu) i **Zysk** (własna kwota, `1.5k`, albo `%` zamiast suwaka).

- **P** – start/stop kupowania albo anulowanie skanu (działa też w otwartym oknie rynku).
- Komendy: `/rynekbot scan`, `/rynekbot start`, `/rynekbot stop`, `/rynekbot dump`.
- Szybkość: kupowanie odpala się **w momencie odebrania pakietu** z serwera (mixin), nie czeka na tick. Odświeżanie rynku ustawiasz w GUI (domyślnie 400 ms) – zbyt niskie wartości mogą skończyć się wyrzuceniem za spam.
- Ceny porównywane są za **1 szt.** (cena oferty / liczba sztuk).

## Budowanie jara (bez instalowania czegokolwiek) – GitHub Actions
1. Załóż darmowe konto na github.com i utwórz nowe repozytorium (np. `rynekbot`).
2. Wgraj do niego zawartość folderu `rynekbot` (przycisk "Add file" -> "Upload files"; ważne, żeby został folder `.github`).
3. Wejdź w zakładkę **Actions** -> workflow **build** -> poczekaj ok. 2-3 minuty, aż zrobi się zielony.
4. W tym przebiegu na dole w **Artifacts** pobierz `rynekbot-jar` (zip z plikiem `rynekbot-1.0.0.jar`).
5. Wypakuj i wrzuć `rynekbot-1.0.0.jar` do `%appdata%\.minecraft\mods` (obok Fabric API dla 1.21.4).
Jeśli build się wywali na błędzie kompilacji, wklej log z Actions.

(Albo lokalnie: Java 21 + Gradle, `gradle build`, jar w `build/libs/`.)

## Kalibracja (WAŻNE – zrób przed użyciem)
Ustawienia okna rynku wzięte z gotowego profilu anarchia.gg w BK-Rynek, ale mod nie był testowany na serwerze:
- `priceRegex` – szuka ceny po słowie „Koszt” w opisie oferty,
- `nextPageSlot` = 26 (przycisk następnej strony), `confirmSlot` = 11 (przycisk „kup” w oknie potwierdzenia),
- `sortingSlot` = 53 i `sortingKeyword` = „najnowsz” (przełączanie sortowania na najnowsze).

Sprawdź je: wejdź na serwer i wpisz `/rynekbot dump`. Mod otworzy `/ah` i wypisze oferty (slot, id, nazwa, lore, wykryta cena).
- Jeśli przy ofertach jest `cena: -1.0`, popraw `priceRegex` w `config/rynekbot.json` (grupa 1 = liczba, grupa 2 = sufiks k/m/b/mld).
- Jeśli skan nie przechodzi na kolejne strony, popraw `nextPageSlot`.
- Jeśli po kliknięciu oferty nic się nie kupuje, popraw `confirmSlot` (albo ustaw -1 i uzupełnij `confirmItems`).
- Jeśli sortowanie przeszkadza, ustaw `sortEnabled` na `false`.

## Uwagi
- Mod nie był kompilowany ani testowany na serwerze – to pierwsza wersja do dopracowania po kalibracji.
- Zautomatyzowane klikanie może być na serwerze zakazane/wykrywane – używasz na własne ryzyko.
